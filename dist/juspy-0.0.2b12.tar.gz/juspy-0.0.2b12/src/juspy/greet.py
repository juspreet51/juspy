def hello():
    return "Hello World!!"
    
def namastey():
    print("नमस्ते मित्र")
    # return "Namastey Mitra!!"

def ni_hao():
    print("朋友你好 ")

def hola():
    print("Hola, cariño ")

def bonjour():
    print("Bonjour chéri")
    
def schatz():
    print("Hallo, Schatz")
    
def ahlan():
    print("مرحبا عزيزتي")
    
def privet():
    print("Privet, dorogoy")