def fit():
    print("Fit Methhod Called")