def hello():
    return "Hello World!!"
    
def namastey():
    return "नमस्ते मित्र"

def ni_hao():
    return "朋友你好 "

def hola():
    return "Hola, cariño "

def bonjour():
    return "Bonjour chéri"
    
def schatz():
    return "Hallo, Schatz"
    
def ahlan():
    return "مرحبا عزيزتي"
    
def privet():
    return "Privet, dorogoy"