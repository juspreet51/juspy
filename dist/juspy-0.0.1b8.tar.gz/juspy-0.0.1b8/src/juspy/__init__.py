from .plot import *
from .greet import *

# Define the seaborn version
__version__ = "0.0.1b8"