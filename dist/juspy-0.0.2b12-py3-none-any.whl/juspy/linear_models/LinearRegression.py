def fit_predict(X_train, X_test, y_train, y_test):
    predictions="predictions"
    rmse="rmse"
    return predictions, rmse