def hello():
    return "Hello World!!"
def namastey():
    return "Namastey Mitra!!"